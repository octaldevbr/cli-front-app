import Utils from "@octaldev/utils";

export default Utils.upgradeTheme({
    primary: "#277ee3",
    black: "#000000",
    white: "#FFFFFF",
    red: "#E91717",
})
