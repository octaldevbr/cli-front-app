export { default as AppTitle } from "./AppTitle/";
export { default as AppButton } from "./AppButton/";
export { default as AppLoader } from "./AppLoader/";
export { default as AppText } from "./AppText/";
export { default as AppIcon } from "react-native-vector-icons/MaterialIcons";
