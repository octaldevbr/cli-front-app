#!/usr/bin/env node

console.log("This is post init script");